
document.addEventListener("DOMContentLoaded",()=>{
  const menu=document.querySelector(".menu"), links=document.querySelector(".navlinks");
  if(menu) menu.addEventListener("click",()=>links.classList.toggle("open"));
  document.querySelectorAll("[data-year]").forEach(el=>el.textContent=new Date().getFullYear());
  document.querySelectorAll("[data-demo]").forEach(form=>{
    form.addEventListener("submit",e=>{
      e.preventDefault();
      const msg=form.querySelector(".form-message");
      if(msg){msg.textContent="Thank you. This demo form is ready to connect to NEHAM's email/CRM endpoint.";msg.hidden=false;}
    });
  });
});
